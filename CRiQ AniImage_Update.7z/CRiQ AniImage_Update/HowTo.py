Se foloseste functia din ui.py

LoadElementAniImage

				for image in value["images"]:
					window.AppendImageScale(image, float(value["x_scale"]), float(value["y_scale"]))



Un mic exemplu:

loadingwindow.py (uiscript)

		{
			"name" : "ANICRiQ_LOADING",
			"type" : "ani_image", "x" : 0, "y" : 0,
			"x_scale" : float(SCREEN_WIDTH) / 1920.0, # REZOLUTIE WIDTH (x_scale)
			"y_scale" : float(SCREEN_HEIGHT) / 1080.0, # REZOLUTIE HEIGHT (y_scale)
			"images" : (ROOT + "1.png", # Images -> call
			ROOT + "2.png",
			ROOT + "3.png",
			),
		},


Se foloseste x_scale si y_scale pentru scalarea imaginilor
SE POATE FOLOSI INCLUSIV PENTRU LoadElementExpandedImage. Trebuie doar adaugat cum trebuie.