#Cauta si inlocuieste sau adapteaza


	def LoadElementAniImage(self, window, value, parentWindow):
		if False==self.CheckKeyList(value["name"], value, self.ANI_IMAGE_KEY_LIST):
			return False

		if True==value.has_key("delay"):
			window.SetDelay(value["delay"])

		if app.CRiQ_SCALE_FUNCTION: # WORKING WITH SHOULDER SASH AND PET !!!
			if True == value.has_key("x_scale") and True == value.has_key("y_scale"):
				for image in value["images"]:
					window.AppendImageScale(image, float(value["x_scale"]), float(value["y_scale"]))
			else:
				for image in value["images"]:
					window.AppendImage(image)
		else:
			for image in value["images"]:
				window.AppendImage(image)

		if value.has_key("width") and value.has_key("height"):
			window.SetSize(value["width"], value["height"])

		self.LoadDefaultData(window, value, parentWindow)
		return True

#Adauga in class AniImageBox

	if app.CRiQ_SCALE_FUNCTION:
		def SetScale(self, fx, fy):
			wndMgr.SetAniImgScale(self.hWnd, fx, fy)
		def AppendImageScale(self, filename, scale_x, scale_y):
			wndMgr.AppendImageScale(self.hWnd, filename, scale_x, scale_y)
