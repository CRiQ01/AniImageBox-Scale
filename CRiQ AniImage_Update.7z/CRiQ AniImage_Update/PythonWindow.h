////////////////////////
///////08.07.2022///////
////////////////////////
PythonWindow.h
/***
Cauta std::vector<CGraphicExpandedImageInstance*> m_ImageVector;
Adauga mai !JOS!:
***/
#ifdef _CRiQ_ANI_SCALE_
		std::queue<std::string> m_ImageFileNames;
		std::function<void(CGraphicExpandedImageInstance*)> m_SetRenderingRect, m_SetRenderingMode, m_SetDiffuseColor;
#endif

/***
Cauta void ResetFrame();
Adauga mai jos:
***/

#ifdef _CRiQ_ANI_SCALE_
		void ClearEntireVector();
#endif