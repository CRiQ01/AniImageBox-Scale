////////////////////////
///////08.07.2022///////
////////////////////////
PythonWindow.cpp
/***
Cauta  void CAniImageBox::AppendImage

Inlocuieste toata functia cu asta:
***/
#ifdef _CRiQ_ANI_SCALE_
    void CAniImageBox::AppendImage(const char * c_szFileName)
    {
        m_ImageFileNames.push(c_szFileName);
    }
#else
	FUNCTIA VOASTRA. PENTRU CEI CU SHOULDER SASH CU DIFFUSE COLOR AVETI DE ADAUGAT R G B A IN FUNCTIE SI SA ADAPTATI
#endif

/*** Cauta CAniImageBox::OnUpdate

Adauga in functie (La inceput dupa { )

***/

        if (!m_ImageFileNames.empty())
        {
            const std::string& stFileName = m_ImageFileNames.front();

            CResource* pResource = CResourceManager::Instance().GetResourcePointer(stFileName.c_str());
            if (pResource->IsType(CGraphicImage::Type()))
            {
                CGraphicExpandedImageInstance* pImageInstance = CGraphicExpandedImageInstance::New();
                pImageInstance->SetImagePointer(static_cast<CGraphicImage*>(pResource));

                if (pImageInstance->IsEmpty())
                {
                    CGraphicExpandedImageInstance::Delete(pImageInstance);
                }
                else
                {
                    pImageInstance->SetPosition(m_rect.left, m_rect.top);

                    if (m_SetRenderingRect)
                        m_SetRenderingRect(pImageInstance);

                    if (m_SetRenderingMode)
                        m_SetRenderingMode(pImageInstance);

                    if (m_SetDiffuseColor)
                        m_SetDiffuseColor(pImageInstance);

                    m_ImageVector.push_back(pImageInstance);
                }
            }

            m_ImageFileNames.pop();
        }
/***
Cauta void CAniImageBox::SetRenderingRect
Inlocuieste cu
***/
#ifdef _CRiQ_ANI_SCALE_
    void CAniImageBox::SetRenderingRect(float fLeft, float fTop, float fRight, float fBottom)
    {
        m_SetRenderingRect = std::bind(&CGraphicExpandedImageInstance::SetRenderingRect, std::placeholders::_1, fLeft, fTop, fRight, fBottom);
        std::for_each(m_ImageVector.begin(), m_ImageVector.end(), m_SetRenderingRect);
    }
#else
	void CAniImageBox::SetRenderingRect(float fLeft, float fTop, float fRight, float fBottom)
	{
		FSetRenderingRect setRenderingRect;
		setRenderingRect.fLeft = fLeft;
		setRenderingRect.fTop = fTop;
		setRenderingRect.fRight = fRight;
		setRenderingRect.fBottom = fBottom;
		for_each(m_ImageVector.begin(), m_ImageVector.end(), setRenderingRect);
	}
#endif
/***
Cauta void CAniImageBox::SetRenderingMod
Inlocuieste cu
***/
#ifdef _CRiQ_ANI_SCALE_
    void CAniImageBox::SetRenderingMode(int iMode)
    {
        m_SetRenderingMode = std::bind(&CGraphicExpandedImageInstance::SetRenderingMode, std::placeholders::_1, iMode);
        std::for_each(m_ImageVector.begin(), m_ImageVector.end(), m_SetRenderingMode);
    }
#else
	void CAniImageBox::SetRenderingMode(int iMode)
	{
		FSetRenderingMode setRenderingMode;
		setRenderingMode.iMode = iMode;
		for_each(m_ImageVector.begin(), m_ImageVector.end(), setRenderingMode);
	}
#endif
/***
Cauta void CAniImageBox::SetDiffuseColor
Inlocuieste cu
***/
#ifdef _CRiQ_ANI_SCALE_
    void CAniImageBox::SetDiffuseColor(float fR, float fG, float fB, float fA)
    {
        m_SetDiffuseColor = std::bind(&CGraphicExpandedImageInstance::SetDiffuseColor, std::placeholders::_1, fR, fG, fB, fA);
        std::for_each(m_ImageVector.begin(), m_ImageVector.end(), m_SetDiffuseColor);
    }
#else
	void CAniImageBox::SetDiffuseColor(float r, float g, float b, float a)
	{
		FSetDiffuseColor setDiffuseColor;
		setDiffuseColor.r = r;
		setDiffuseColor.g = g;
		setDiffuseColor.b = b;
		setDiffuseColor.a = a;
		for_each(m_ImageVector.begin(), m_ImageVector.end(), setDiffuseColor);
	}
#endif
/***
Adauga sub void CAniImageBox::SetDiffuseColor
***/
#ifdef _CRiQ_ANI_SCALE_
	void CAniImageBox::ClearEntireVector() //  
	{
		while (!m_ImageFileNames.empty())
			m_ImageFileNames.pop();

		for_each(m_ImageVector.begin(), m_ImageVector.end(), CGraphicExpandedImageInstance::DeleteExpandedImageInstance);
		m_ImageVector.clear(); // CLEAR
	}
#endif
/***
Cauta void CAniImageBox::OnChangePosition()
Inlocuieste cu
***/
#ifdef _CRiQ_ANI_SCALE_
    void CAniImageBox::OnChangePosition()
    {
        std::for_each(m_ImageVector.begin(), m_ImageVector.end(),
            std::bind(&CGraphicExpandedImageInstance::SetPosition, std::placeholders::_1, m_rect.left, m_rect.top));
    }
#else
	void CAniImageBox::OnChangePosition()
	{
		FChangePosition changePosition;
		changePosition.fx = m_rect.left;
		changePosition.fy = m_rect.top;
		for_each(m_ImageVector.begin(), m_ImageVector.end(), changePosition);
	}
#endif
