/***
Adauga
***/

#if defined(_ANI_SCALE_PYTHON_)
	PyModule_AddIntConstant(poModule, "CRiQ_SCALE_FUNCTION", 1);
#else
	PyModule_AddIntConstant(poModule, "CRiQ_SCALE_FUNCTION", 0);
#endif