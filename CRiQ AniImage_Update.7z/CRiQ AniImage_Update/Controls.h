/***
Adauga oriunde
***/

#define _CRiQ_ANI_SCALE_ // CAniImageBox Update
#if defined _CRiQ_ANI_SCALE_ 
#define _ANI_SCALE_PYTHON_ // Images call created
#endif